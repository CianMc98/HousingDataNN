#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Here are all the necessary imports
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Sequential
import tensorflow.keras.metrics

import pandas as pd
import matplotlib.pyplot as plt

import numpy as np
import seaborn as sns

from sklearn import preprocessing
from sklearn.model_selection import train_test_split


# In[2]:


#Read in the data from Kaggle dataset from Github and print data, removes useless columns from csv
readData = pd.read_csv("https://raw.githubusercontent.com/CianMc98/HousingDataNN/main/Housing.csv")
readData = readData.drop(columns= ["mainroad", "guestroom", "basement", "hotwaterheating", "airconditioning",
                                   "prefarea", "furnishingstatus" ])

readData.head()


# In[3]:


#Identify the rows(all remaining rows) and column (number of bedrooms in the house)
row = readData.iloc[:,1:5].values
col = readData.iloc[:,0].values


# In[4]:


#Normalise the input data 0-1 with scikit - preprocessing
minmaxScaler = preprocessing.MinMaxScaler()
x = minmaxScaler.fit_transform(row)


#Remove comment from next line to normalise output data between 0-1, commented out as results 
col = np.interp(col, (col.min(), col.max()), (0, +1))
col[:50]


# In[5]:


sns.pairplot(readData[['price', 'area' , 'bedrooms']], diag_kind='kde')


# In[6]:


#Using scikit to split dataset into training and test/validation data and then split dataset into test and validation data
trainx, testvalx, trainy, testvaly = train_test_split(x, col, test_size = 0.3)
valx, testx, valy, testy = train_test_split(testvalx, testvaly, test_size = 0.5)

print(trainx.shape, valx.shape, testx.shape, trainy.shape, valy.shape, testy.shape)


# In[7]:


#Setting up the Model for NN ( 32 layer x 32 layer and output to 1 layer )
# Sequential and Dense, already imported from tensorflow.keras.~
model = Sequential([
    Dense(32, activation = 'relu', input_shape=(4,)), 
    Dense(32, activation = 'relu'),
    Dense(1, activation = 'linear'),
    
])


model.summary()


# In[8]:


#Configuring the Model for optimisation
model.compile(optimizer= 'adam',
              loss = 'mse',
              metrics = ["accuracy"],
             )


# In[9]:


#Fit the model 
hist = model.fit(trainx, trainy, validation_data = (valx, valy), epochs = 50, batch_size = 64, validation_split = 0.175)


# In[10]:


# Plotting loss to graph
plt.plot(hist.history['loss'])
plt.plot(hist.history['val_loss'])
plt.title('Loss in Model')
plt.ylabel('Loss:')
plt.xlabel('Epoch:')
plt.legend(['Training', 'Validation'], loc='upper center')
plt.show()

