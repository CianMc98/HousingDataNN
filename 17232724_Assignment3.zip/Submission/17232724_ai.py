import numpy as np
import os
import pylab
import random
from keras.layers import Dense, Flatten, Input, MaxPool1D
from keras.layers.convolutional import Conv1D
from tensorflow.keras import optimizers, Model
import tensorflow.keras.backend as K


import graphical, game

#  Checks for folder where the best score of a game is stored
pathForModel = os.path.join(os.getcwd(), 'model_learning')
if not os.path.exists(pathForModel):
    os.mkdir(pathForModel)
else:
    print("Folder: model_learning already exists")

filename = pathForModel + "/best_score.txt"


#  Create the board for the game as an array
def createBoard(board):
    r = board.replace('\n', '')
    arr = []
    for character in r:
        number = ord(character) - 96
        arr.append(number)
    out = np.asarray(splitArr(arr))
    out.shape = (1, 10, 8)
    return out


# Used to split the elements of an array
def splitArr(arr):
    return [char for char in arr]


# The Actor Critic Class
class A2CAgent:
    def __init__(self):
        self.reward_memory = []
        self.state_memory = []
        self.action_memory = []

        self.current_game = 1
        self.episodes = 1000
        self.learning_rate = 0.1
        self.gamma = 0.99
        self.turns, self.actions = [], []
        self.x_val, self.y_val, self.binary_val = [], [], []
        self.states, self.scores, self.final_scores = [], [], []
        self.io = ReadWriteData()
        self.total_score, self.average, self.max_score = 0, 0, 0
        self.optimiser = optimizers.Adam(self.learning_rate)
        self.state_size = (10, 8)
        self.action_space = 160

        self.actor, self.critic = self.create_model()
        self.load_model(self.io.read(filename))

    #  Predicts the state
    def act(self, state):
        prediction = self.actor.predict(state)
        return prediction

    def choose_action(self, observation):
        state = observation[np.newaxis, :]
        probab = self.critic(state)[0]
        action = np.random.choice(self.action_space, p=probab)

        return action

    def store_transition(self, observation, action, reward):
        self.action_memory.append(action)
        self.state_memory.append(observation)
        self.reward_memory.append(reward)

    # Creates the model for the Neural Network
    def create_model(self):
        x_input = Input(shape=self.state_size)
        conv = Conv1D(filters=128, kernel_size=3, strides=1, activation='relu')(x_input)
        poolLayer = MaxPool1D(pool_size=2)(conv)
        flatten = Flatten()(poolLayer)
        convLayer = Dense(128, activation='relu')(flatten)
        val = Dense(32, activation='relu')(convLayer)

        #  3 inputs: x and y directions and binary value
        x = Dense(8, activation='relu', name='x')(val)
        y = Dense(10, activation='relu', name='y')(val)
        binary = Dense(2, activation='softmax', name='bin')(val)

        x_value = Dense(1, activation='linear', name='x_critic')(val)
        y_value = Dense(1, activation='linear', name='y_critic')(val)
        binary_value = Dense(1, activation='linear', name='bin_critic')(val)

        # trying to create own loss function rather than using categorical crossentropy
        # adv = Input(shape=(self.state_size,))
        #
        # def custom_loss(y_true, y_pred):
        #     action_true = y_true[:, :n_outputs]
        #     advantage = y_true[:, n_outputs:]
        #
        #     return -tfc.log(y_pred.prob(action_true) + 1e-5) * advantage

        # Build Actor and Critic Model
        actor = Model(inputs=x_input, outputs=[x, y, binary])
        critic = Model(inputs=x_input, outputs=[x_value, y_value, binary_value])
        critic.compile(loss={'x_critic': 'mse',
                             'y_critic': 'mse',
                             'bin_critic': 'mse'},
                       optimizer=self.optimiser)
        actor.compile(loss={'x': 'categorical_crossentropy',
                            'y': 'categorical_crossentropy',
                            'bin': 'categorical_crossentropy'},
                      optimizer=self.optimiser)

        actor.summary()
        critic.summary()

        return actor, critic

    # Get the discounted scores for the reward
    def discount_scores(self, scores):
        running_add = 0
        discounted_result = np.zeros_like(scores)
        discounted_result = discounted_result.astype(float)
        for i in reversed(range(0, len(scores))):
            running_add = running_add * self.gamma + scores[i]
            discounted_result[i] = running_add

        discounted_result -= np.mean(discounted_result)
        discounted_result /= np.std(discounted_result)
        return discounted_result

    # Replay Buffer to train Model
    def replayBuffer(self):
        states = np.vstack(self.states)
        x_val = np.vstack(self.x_val)
        y_val = np.vstack(self.y_val)
        binary_val = np.vstack(self.binary_val)
        disc_rewards = self.discount_scores(self.scores)

        # Predict states
        x_values = self.critic.predict(states)[0][0]
        y_values = self.critic.predict(states)[0][1]
        binary_values = self.critic.predict(states)[0][2]

        xAdv = disc_rewards - x_values
        yAdv = disc_rewards - y_values
        binaryAdv = disc_rewards - binary_values

        # Training A2C
        self.actor.fit(states,  {'x': x_val, 'y': y_val, 'bin': binary_val}, sample_weight={'x': xAdv, 'y': yAdv, 'bin': binaryAdv}, epochs=50, verbose=0)
        self.critic.fit(states, {'x_critic': disc_rewards, 'y_critic': disc_rewards, 'bin_critic': disc_rewards}, epochs=50, verbose=0)
        #  Resets all values
        self.states, self.actions, self.scores,  self.x_val, self.y_val, self.binary_val = [], [], [], [], [], []
        self.total_score = 0

    # trying to create advanced learning method
    # def learn(self):
    #     state = np.array(self.state)
    #     action = np.array(self.action)
    #     reward = np.array(self.reward)
    #
    #     actions = np.zeros([len(action), 160])
    #     actions[np.arange(len(action)), action] = 1
    #
    #     G = np.zeros_like(reward)
    #     for t in range(len(reward)):
    #         G_sum = 0
    #         discount = 1
    #         for k in range(t, len(reward)):
    #             G_sum += reward[k] * discount
    #             discount *= self.gamma
    #         G[t] = G_sum
    #     mean = np.mean(G)
    #     std = np.std(G) if np.std(G) > 0 else 1
    #     self.G = (G - mean) / std
    #
    #     cost = self.policy.train_on_batch([state, self.G], actions)
    #
    #     self.state = []
    #     self.action = []
    #     self.reward = []
    #
    #     return cost

    #  loads model from folder (actor,critic)
    def load_model(self, name):
        nameScore = name.decode("utf-8")
        print(nameScore)
        self.max_score = int(nameScore)
        if self.max_score != -125:
            self.actor.load_weights(os.path.join(pathForModel, nameScore + "_Actor.h5"))
            self.critic.load_weights(os.path.join(pathForModel, nameScore + "_Critic.h5"))

    #  Saves model in folder: model_learning
    def save_model(self, name):
        self.actor.save_weights(os.path.join(pathForModel, name + "_Actor.h5"))
        self.critic.save_weights(os.path.join(pathForModel, name + "_Critic.h5"))

    pylab.figure(figsize=(18, 9))

    # ai callback, actions made by Actor
    def ai_callback(self, board, score, moves_left, state, reward):
        state = createBoard(board)
        # the Actor picks an action
        action = self.act(state)
        x_val = np.argmax(action[0][0], axis=0)
        y_val = np.argmax(action[1][0], axis=0)
        dir_binary = np.argmax(action[2][0], axis=0)
        if score > reward:
            action = []
        #  returns result
        result = x_val, y_val, dir_binary
        #  appends actions array
        self.x_val.append(np.asarray(action[0]))
        self.y_val.append(np.asarray(action[1]))
        self.binary_val.append(np.asarray(action[2]))
        self.actions.append([np.asarray(action[0]), np.asarray(action[1]), np.asarray(action[2])])

        print(result)
        return result

    # transition callback, reward moves
    def transition_callback(self, board, move, score_delta, next_board, moves_left):
        state = createBoard(board)
        self.states.append(state)
        self.total_score += score_delta
        self.scores.append(score_delta)
        pass  # This can be used to monitor outcomes of moves

    # End of Game, saves best score
    def end_of_game_callback(self, boards, scores, moves, final_score):
        self.replayBuffer()
        self.final_scores.append(final_score)
        if final_score >= self.max_score:
            self.max_score = final_score
            self.save_model(str(final_score))
            SAVING = "SAVING"
            self.io.write(filename, data=str(final_score))
        else:
            SAVING = ""
        print("Game: {}/{}, Final Score: {} {}".format(self.current_game, self.episodes, final_score, SAVING))

        if self.current_game == self.episodes:

            # plot the graph for NN
            pylab.plot(self.final_scores, 'b')
            pylab.ylabel('Score', fontdict=16)
            pylab.xlabel('Games', fontdict=16)
            try:
                pylab.savefig("FinalResult" + ".png")
            except OSError:
                pass
            return False
        else:
            self.current_game += 1
            return True  # True = play another, False = Done


# Class used to read and write from/to a file, used with loading/saving weights
class ReadWriteData:
    @staticmethod
    def read(name):
        line = open(name, "rb")
        output = line.read()
        line.close()
        return output

    @staticmethod
    def write(name, data):
        line = open(name, "wb")
        line.write(data.encode('utf-8'))
        line.close()


# Runs the game
if __name__ == '__main__':
    speedup = 10.0
    agent = A2CAgent()
    g = graphical.Game(agent.ai_callback, agent.transition_callback, agent.end_of_game_callback, speedup)
    g.run()
